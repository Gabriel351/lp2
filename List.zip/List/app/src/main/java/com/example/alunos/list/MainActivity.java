package com.example.alunos.list;

import android.app.ListActivity;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ArrayAdapter;

public class MainActivity extends ListActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        String[] item = new String[]{"Nome1","Nome2","Nome3"};
        ArrayAdapter<String> adaptador = new ArrayAdapter<String>(this.android.R.Layout.activity_main, item);
        setListAdapter(adaptador);
    }
}
