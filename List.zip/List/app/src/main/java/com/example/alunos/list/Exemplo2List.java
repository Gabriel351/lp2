package com.example.alunos.list;

import android.app.ListActivity;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.SimpleAdapter;

import java.util.ArrayList;
import java.util.HashMap;

public class Exemplo2List extends ListActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_exemplo2_list);
        ArrayList<HashMap<String,String>> list = new ArrayList<HashMap<String,String>>();

        for (int i = 0; i < 10; i++) {
            HashMap<String,String> item = new HashMap<String,String>();
            item.put("nome", "Nome"+i);
            item.put("fone", "Fone"+i);
            list.add(item);
        }

        String[] from = new String[] {"nome","fone"};
        int[] to = new int[] {android.R.id.text1, android.R.id.text2};
        int layoutNativo = android.R.layout.two_line_list_item;

        setListAdapter(new SimpleAdapter(this, list, layoutNativo, from, to));
    }
}
