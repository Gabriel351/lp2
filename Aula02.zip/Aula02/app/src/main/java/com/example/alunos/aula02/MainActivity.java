package com.example.alunos.aula02;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
    public void abrir_tela1 (View v) {
        Intent it = new Intent(this,Tela1_activity.class);
        startActivity(it);
    }

    public void abrir_tela2 (View v) {
        //pegar id do editText e seu valor
        EditText input = (EditText) findViewById(R.id.inputNome);
        String nome = input.getText().toString();
        //Intent -> intenção de fazer algo no celular
        Intent it = new Intent(this,Tela2_activity.class);
        //usado para criar um vetor com chaves(nomes)
        Bundle b = new Bundle();
        //adicionar a string do editText no bundle
        b.putString("p_nome", nome);
        //adicionar bundle na intent
        it.putExtras(b);
        //mudar de tela
        startActivity(it);
    }
}
