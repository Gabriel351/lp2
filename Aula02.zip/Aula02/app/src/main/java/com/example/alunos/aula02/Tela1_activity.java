package com.example.alunos.aula02;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class Tela1_activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela1_activity);
    }
}
