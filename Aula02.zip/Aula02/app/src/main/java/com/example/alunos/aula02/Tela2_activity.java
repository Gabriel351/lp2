package com.example.alunos.aula02;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class Tela2_activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela2_activity);
        //pegar a Intent por parametro
        Intent it2 = getIntent();
        //pegar o Bundle por parametro
        Bundle b = it2.getExtras();
        //pegar a string do bundle pela chave
        String a = b.getString("p_nome");
        //pegar o id do textview e exibit a string
        TextView txt1 = (TextView) findViewById(R.id.tela2_view);
        txt1.setText(a);
    }


}
